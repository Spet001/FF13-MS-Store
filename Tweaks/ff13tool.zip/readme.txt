Final Fantasy XIII extraction/repacking command line tool. v1.4

There's 3 different ways to use the tool:
- Extract all files from a container file. Example: ff13tool -x -ff13 filelist_scrc.win32.bin white_scrc.win32.bin
- Repack all files into a container file. Note that it requires the filelist as it uses it as base. It has a limitation that it can't add new files, it'll compress the same files as the ones listed in filelist. Example: ff13tool -c -ff13 filelist_scrc.win32.bin white_scrc
- Import one file into container file. Repacking an entire container file is slow since they're so big, so this is intended for quick iteration on testing mods. Note that it appends file data to the end of the container file, so it'll make the container file larger each time you do this. Example: ff13tool -i -ff13 filelist_scrc.win32.bin white_scrc.win32.bin white_scrc/chr/pc/c205/bin/c205.win32.trb
- Import all files from a directory file into container file. Similar to above behaviour, but it'll scan a directory for files and import all it finds. Example: ff13tool -i -all -ff13 filelist_scrc.win32.bin white_scrc.win32.bin white_scrc

Some notes:
- This is only tested with PC version of FFXIII. I don't know if it works on 360 and PS3 versions.
- It also supports PC versions of FFXIII-2 and FFXIII-3 but you need the ffxiiicrypt tool by Echelo to decrypt and encrypt the filelist files (you'll need the latest version of this tool as of December 2015). Use "-ff132" or "-ff133" when extracting/repacking files from those games.
- As mentioned above, since new filelist is based on the old filelist, the tool can't add all new files. It has to be replacing files already in the container file.
- Zone container files can be extracted/repacked too. Their corresponding filelists is in white_imgc.win32.bin.
- Any container file with "c" are Japanese files, and any container file with "u" are English files. Many of these are actually identical. There's no difference between white_scrc.win32.bin and white_scru.win32.bin in FF13.
- I have no idea what white_scrc.win32.sdat is used for. I have tried experimenting with it and I couldn't see any ingame effect. It might not actually be used for anything.
- The batch files are configured to extract/repack the img and scr Japanese container files, but only for FF13. Edit the batch files to have them work with FF13-2, or just use the tool in command prompt.
- Visual Studio C++ 2008 runtime libaries needs to be installed (more than likely, this is already installed on your computer): http://www.microsoft.com/en-us/download/details.aspx?id=29